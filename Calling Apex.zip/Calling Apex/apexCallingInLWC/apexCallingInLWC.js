import { LightningElement, track, wire } from 'lwc';

import accDetails from '@salesforce/apex/ApexCallinginLWC.account';
import conDetails from '@salesforce/apex/ApexCallinginLWC.contact';
import oppDetails from '@salesforce/apex/ApexCallinginLWC.opportunity';

const accColoums=[
    {label:'Name', fieldName:'Name'},
    {label: 'Phone', fieldName:'Phone'}
];

const concoloums=[
    {label: 'LastName', fieldName:'LastName'},
    {label: 'Phone', fieldName:'Phone'}
];

// const oppColoums=[
//     {label:'Name', fieldName: 'Name'},
//     {label: 'closedDate', fieldName: 'CloseDate'},
//     {label: 'StageName', fieldName: 'StageName'}

// ];

export default class ApexCallingInLWC extends LightningElement {
   
    
    @track contact;
    opportunity;
   
   
    @track coloumss=accColoums;
    @track coloumscc=concoloums;


    @wire(accDetails)
    wiredAccount

    @wire(conDetails)
    wiredContact({data,error}){
        if(data){
            this.contact=data;
        }
        else if(error){
            console.log('Error in getting contact is :', error);
        }
    }

    handlerClick(){
        oppDetails().then(result =>{
            this.opportunity=result;
        }).catch(error=>{
            console.log('There was an Error while fetching Opp Details',error);
        })
    }
}